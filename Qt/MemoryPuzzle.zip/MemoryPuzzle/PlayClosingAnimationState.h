#ifndef PLAYCLOSINGANIMATION_H
#define PLAYCLOSINGANIMATION_H

#include "GameState.h"
#include <QTimer>

class GameLogic;

class PlayClosingAnimationState : public GameState
{
public:
    PlayClosingAnimationState(GameLogic* gameLogic);

    void enter();
    void exit();
    void handleMousePress(int x, int y);
public slots:
    void update();

private:
    GameLogic* mGameLogic;
    QTimer* mTimer;
};


#endif // PLAYCLOSINGANIMATION_H
