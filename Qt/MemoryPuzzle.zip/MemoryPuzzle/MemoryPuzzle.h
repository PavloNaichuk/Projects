#ifndef MEMORYPUZZLE_H
#define MEMORYPUZZLE_H

class MemoryPuzzle
{
public:
    int runGame(int argc, char* argv[]);
};

#endif // MEMORYPUZZLE_H
