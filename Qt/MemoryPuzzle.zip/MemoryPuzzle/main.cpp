#include "MemoryPuzzle.h"

int main(int argc, char* argv[])
{
    MemoryPuzzle memoryPuzzle;
    return memoryPuzzle.runGame(argc, argv);
}

