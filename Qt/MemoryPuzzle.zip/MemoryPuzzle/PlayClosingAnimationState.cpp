#include "SelectSecondCardState.h"
#include "SelectFirstCardState.h"
#include "PlayClosingAnimationState.h"
#include "GameLogic.h"
#include "CardBoard.h"

PlayClosingAnimationState::PlayClosingAnimationState(GameLogic* gameLogic)
    : mGameLogic(gameLogic)
    , mTimer(0)
{
}

void PlayClosingAnimationState::enter()
{
    mTimer = new QTimer();
    QObject::connect(mTimer, SIGNAL(timeout()), this,  SLOT(update()));

    mTimer->start(5000);

}

void PlayClosingAnimationState::update()
{
    mGameLogic->getSelectedFirstCard()->setOpened(false);
    mGameLogic->getSelectedSecondCard()->setOpened(false);
    mGameLogic->setCurrentState(mGameLogic->getSelectFirstCardState());
}

void PlayClosingAnimationState::exit()
{
    mTimer->stop();
}

void PlayClosingAnimationState::handleMousePress(int x, int y)
{
}
