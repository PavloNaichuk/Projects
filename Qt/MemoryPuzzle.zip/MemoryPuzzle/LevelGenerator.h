#ifndef LEVELGENERATOR_H
#define LEVELGENERATOR_H

#include "CardBoard.h"

class LevelGenerator
{
public:
    static Card* create();
};

#endif // LEVELGENERATOR_H
